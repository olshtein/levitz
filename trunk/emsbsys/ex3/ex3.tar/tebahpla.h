#ifndef __TEBAHPLA_H__
#define __TEBAHPLA_H__

#define NULL_CHAR ((char)-1)
#include "common_defs.h"
CHARACTER getCHAR(char ch,bool selected);
void * my_memcpy (void *destaddr, void const *srcaddr, int len);
#endif
